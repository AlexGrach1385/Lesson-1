package HomeWorksApp;
import java.util.Scanner;

public class HomeWorkApp {
    private static void Main() {
    }

    public static void main(String args[]) {
        System.out.println("Orange");
        System.out.println("Banana");
        System.out.println("Apple");

        checkSumSign();// wtf зачем это и почему без него не работает?

        printColor();// wtf зачем это и почему без него не работает? вызов метода???

        compareNumbers(); //Видимо это обьявление метода в классе?
    }


    public static void checkSumSign() {
        int a = -5;
        int b = 2;
        int c = a + b;
        if (c >= 0) {
            System.out.println(" Summ positive ");
        }
        else {
        System.out.println(" Summ negative ");
        }
    }

    public static void printColor()  {
        Scanner in = new Scanner(System.in);
        System.out.println(" input the number from 0 to 100");
        int value = in.nextInt();
        if ( value <= 0) {
            System.out.println(" red ");
        } else if (value >= 0 && value <= 100) {
            System.out.println(" yellow ");
        } else {
            System.out.println(" green ");
        }
    }

    public static void compareNumbers() {
        int a = 10; //переменные дублируются из предыдущих заданий. Возможно будет работать некорректно
        int b = 2;

        if (a >= b) {
            System.out.println(" a >= b ");
        }
        else {
            System.out.println(" a < b ");
        }
    }



}// конец класса. все что до скобки входит в класс




